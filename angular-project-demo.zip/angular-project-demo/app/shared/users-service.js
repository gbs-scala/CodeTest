angular.module('myApp.userService', [])
.service('userService', function() {
    let selectedItem;
    let selectedData;
    const userList = [
        {"id":1,"first_name":"SHARED WORKSPACE","last_name":"MAIL MARSHAL SERVER","hobby":"CORE BUSINESS","disabledprop":"false"},
        {"id":2,"first_name":"SHARED WORKSPACE","last_name":"STATIC SITE SERVER","hobby":"DATA","disabledprop":"false"},
        {"id":3,"first_name":"MANAGED PRINT SERVICE (MPS)","last_name":"NEW EXPORT SYSTEM","hobby":"CORE BUSINESS","disabledprop":"false"},
        {"id":4,"first_name":"DOCUMENTUM / WEB CONTENT","last_name":"WEB SERVER","hobby":"CASE","disabledprop":"false"},
        {"id":5,"first_name":"DOCUMENTUM / WEB CONTENT","last_name":"JOB ACCOUNTING SERVER","hobby":"CASE","disabledprop":"false"},
        {"id":6,"first_name":"DOCUMENTUM / WEB CONTENT","last_name":"WEB SERVER","hobby":"CASE","disabledprop":"false"},
        {"id":7,"first_name":"ACCOUNT PRODUCTION SERVICES (APS)","last_name":"WEB SERVER","hobby":"CORE BUSINESS","disabledprop":"false"},
    ];
	
     const addUser = function(newObj) {
        userList.push(newObj);
    };

    const getUsers = function(){
        return userList;
    };

    const getUser = function(id) {
        return userList.find(user => user.id === id);
    }
    const setItem = function(item) {
        selectedItem = userList.filter((elem => item.indexOf(elem.id) > -1));
    }
    const getItem = function() {
        return selectedItem;
    }
    const getData = function() {
        return selectedData;
    }
    const updateBundle = function(userId, bundle) {
        const id = parseInt(userId, 10);
        let selectedUser = selectedItem.find(user => user.id === id);
        selectedUser['bundle'] = bundle;
    }
    const updateHotfix = function(userId, Hotfix) {
        const id = parseInt(userId, 10);
        let selectedUser = selectedItem.find(user => user.id === id);
        selectedUser['hotfix'] = Hotfix;
    }
    const setData = function() {
        selectedData = selectedItem.filter((elem => elem.bundle || elem.hotfix ));
        console.log(selectedData, 'maximuf')
    }
    const updateSlot = function (time, userId) {
        let selectedUser = selectedItem.find(user => user.id === userId);
        selectedUser['slot'] = time;
    }
    return {
      addUser,
      getUsers,
      setItem,
      getItem,
      updateBundle,
      updateHotfix,
      setData,
      getData,
      updateSlot
    };
  
  });