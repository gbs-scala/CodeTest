'use strict';

angular.module('myApp.view2', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/view2', {
    templateUrl: 'view2/view2.html',
    controller: 'View2Ctrl'
  });
}])

.controller('View2Ctrl', ['$scope', '$filter', '$timeout', function ($scope, $filter, $timeout) {
    $scope.currentPage = 0;
    $scope.pageSize = 35;
    $scope.orderByField = 'id';
    $scope.reverseSort = false;
    $scope.option = [];
    $scope.selectedItem = [];
    $scope.message = '';
    $scope.data = [
        { "id": 1, "server_name": "IRAxxxx1", "service_name": "SHARED WORKSPACE", "server_function": "MAIL MARSHAL SERVER", "os": "WIN2003", "owner": "CORE BUSINESS", "disabledprop": "false" },
        { "id": 2, "server_name": "IRAxxxx2", "service_name": "SHARED WORKSPACE", "server_function": "STATIC SITE SERVER", "os": "WIN2003", "owner": "DATA", "disabledprop": "false" },
        { "id": 3, "server_name": "IRAxxxx3", "service_name": "MANAGED PRINT SERVICE (MPS)", "server_function": "NEW EXPORT SYSTEM", "os": "WIN2008", "owner": "CORE BUSINESS", "disabledprop": "false" },
        { "id": 4, "server_name": "IRAxxxx4", "service_name": "DOCUMENTUM / WEB CONTENT", "server_function": "WEB SERVER", "os": "WIN2008", "owner": "CASE", "disabledprop": "false" },
        { "id": 5, "server_name": "IRAxxxx5", "service_name": "DOCUMENTUM / WEB CONTENT", "server_function": "JOB ACCOUNTING SERVER", "os": "WIN10", "owner": "CASE", "disabledprop": "false" },
        { "id": 6, "server_name": "IRAxxxx6", "service_name": "DOCUMENTUM / WEB CONTENT", "server_function": "WEB SERVER", "os": "WIN7", "owner": "CASE", "disabledprop": "false" },
        { "id": 7, "server_name": "IRAxxxx7", "service_name": "ACCOUNT PRODUCTION SERVICES (APS)", "server_function": "WEB SERVER", "os": "WIN7", "owner": "CORE BUSINESS", "disabledprop": "false" },
    ];

    $scope.data.forEach((element) => {
        $scope.option.push(element.os);
    });
    localStorage.setItem('data', JSON.stringify($scope.data));
    $scope.options = $scope.option.filter((item, pos) => $scope.option.indexOf(item) === pos);
    $scope.q = '';
    $scope.reload = function()
    {
        const allData = JSON.parse(localStorage.getItem('data'));
        $scope.data = allData;
    }
    $scope.selectOption = function(option)
    {
        const allData = JSON.parse(localStorage.getItem('data'));
        $scope.datas = allData.filter((item) => {
            return item.os === $scope.selectedOS;
        });
        $scope.data = $scope.datas;
    }
    $scope.checkAll = function () {
        const newArray = [];
        angular.forEach($scope.data, function (item) {
            item.Selected = $scope.selectAll;
            newArray.push(item.id);
        });
        $scope.selectedItem = newArray;
    };
    $scope.deleteItem = function (id) {
        let x = document.getElementById("snackbar")
        x.className = "show";
        $scope.data = $scope.data.filter(elem => elem.id !== id);
        $scope.message = 'User was deleted successfully';
        $timeout(function(){
           x.className = x.className.replace("show", "");
        }, 2000);
    };
    $scope.selectOne = function (id) {
        if ($scope.selectedItem.includes(id)) {
            const index = $scope.selectedItem.indexOf(id);
            if (index > -1) {
                $scope.selectedItem.splice(index, 1);
            }
        } else {
            $scope.selectedItem.push(id);
        }
        if ($scope.selectedItem.length === 2) {
            angular.forEach($scope.data, function (item) {
                if (!item.Selected === true) {
                    item.disabledprop = true;
                }
            });
        } else {
            angular.forEach($scope.data, function (item) {
               item.disabledprop = false;
            });
        }
        $scope.selectAll = false;
    }
    $scope.getData = function () {
      return $filter('filter')($scope.data, $scope.q)
    }
    $scope.getNumber = function(num) {
        return new Array(num);
    }
    $scope.setPage = function(pageNum) {
        $scope.currentPage = pageNum;
    }
    $scope.numberOfPages=function(){
        $scope.totalPages = Math.ceil($scope.getData().length/$scope.pageSize);
        return $scope.totalPages;
    }
}])
.filter('startFrom', function() {
    return function(input, start) {
        start = +start; //parse to int
        return input.slice(start);
    }
});
